package com.mustafa.converter

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val navy = 0xFF071B42.toInt()
    private val orange = 0xFFFF9900.toInt()
    private val chosen = mutableListOf<Uri>()
    private lateinit var status: TextView
    private lateinit var fileLabel: TextView
    private lateinit var quality: SeekBar
    private lateinit var qualityLabel: TextView
    private var selectedFormat = "JPEG"

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        chosen.clear(); chosen.addAll(uris)
        fileLabel.text = if (uris.isEmpty()) "لم يتم اختيار ملفات" else "تم اختيار ${uris.size} ملف"
        status.text = "جاهز للتنفيذ"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(28))
            setBackgroundColor(0xFFF5F7FB.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "FlipFile"
            textSize = 34f; setTextColor(navy); gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(brand, match())
        val subtitle = TextView(this).apply {
            text = "حوّل صورك وملفاتك بسهولة"
            textSize = 15f; setTextColor(0xFF65718A.toInt()); gravity = Gravity.CENTER
        }
        root.addView(subtitle, match())
        root.addView(space(22))

        val pick = button("＋  اختر الصور والملفات", navy) { picker.launch(arrayOf("image/*")) }
        root.addView(pick, match())
        fileLabel = TextView(this).apply {
            text = "لم يتم اختيار ملفات"; textSize = 14f; setTextColor(0xFF596579.toInt())
            gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(14))
        }
        root.addView(fileLabel, match())

        section(root, "تحويل الصور")
        val formats = Spinner(this)
        formats.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("JPEG", "PNG", "WEBP"))
        formats.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { selectedFormat = listOf("JPEG", "PNG", "WEBP")[position] }
        }
        root.addView(formats, match())
        root.addView(button("حوّل الصور إلى $selectedFormat", orange) { convertImages() }, match())

        section(root, "ضغط الصور")
        qualityLabel = TextView(this).apply { text = "جودة الصورة: 75%"; textSize = 14f; setTextColor(navy) }
        root.addView(qualityLabel, match())
        quality = SeekBar(this).apply { max = 90; progress = 65; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { qualityLabel.text = "جودة الصورة: ${p + 10}%" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        }) }
        root.addView(quality, match())
        root.addView(button("اضغط الصور", navy) { compressImages() }, match())

        section(root, "ملف PDF")
        root.addView(button("اجمع الصور في ملف PDF", orange) { imagesToPdf() }, match())
        root.addView(space(18))
        status = TextView(this).apply {
            text = "اختار ملفات وابدأ"; textSize = 14f; setTextColor(0xFF536078.toInt()); gravity = Gravity.CENTER
            setPadding(dp(12), dp(14), dp(12), dp(14))
        }
        root.addView(status, match())
        val foot = TextView(this).apply { text = "الملفات الناتجة تُحفظ في مجلد Pictures/FlipFile"; textSize = 12f; setTextColor(0xFF7C8799.toInt()); gravity = Gravity.CENTER; setPadding(0, dp(18), 0, 0) }
        root.addView(foot, match())
    }

    private fun convertImages() {
        if (!ensureSelection()) return
        var done = 0
        chosen.forEachIndexed { i, uri ->
            val bitmap = decode(uri) ?: return@forEachIndexed
            val fmt = when (selectedFormat) { "PNG" -> Bitmap.CompressFormat.PNG; "WEBP" -> Bitmap.CompressFormat.WEBP; else -> Bitmap.CompressFormat.JPEG }
            val ext = selectedFormat.lowercase(Locale.ROOT)
            val mime = when (selectedFormat) { "PNG" -> "image/png"; "WEBP" -> "image/webp"; else -> "image/jpeg" }
            val ok = save("flipfile_${stamp()}_$i.$ext", mime) { out -> bitmap.compress(fmt, 92, out) }
            if (ok) done++
            bitmap.recycle()
        }
        status.text = "تم تحويل $done من ${chosen.size} صورة"
    }

    private fun compressImages() {
        if (!ensureSelection()) return
        var done = 0
        chosen.forEachIndexed { i, uri ->
            val bitmap = decode(uri) ?: return@forEachIndexed
            val ok = save("flipfile_compressed_${stamp()}_$i.jpg", "image/jpeg") { out -> bitmap.compress(Bitmap.CompressFormat.JPEG, quality.progress + 10, out) }
            if (ok) done++
            bitmap.recycle()
        }
        status.text = "تم ضغط $done صورة. ملاحظة: الضغط يحفظ نسخة JPEG جديدة."
    }

    private fun imagesToPdf() {
        if (!ensureSelection()) return
        val pdf = PdfDocument()
        var pageNo = 0
        chosen.forEach { uri ->
            val bitmap = decode(uri) ?: return@forEach
            pageNo++
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageNo).create()
            val page = pdf.startPage(pageInfo)
            val scale = minOf(555f / bitmap.width, 802f / bitmap.height)
            val w = (bitmap.width * scale).toInt(); val h = (bitmap.height * scale).toInt()
            val dst = Rect((595 - w) / 2, (842 - h) / 2, (595 + w) / 2, (842 + h) / 2)
            page.canvas.drawBitmap(bitmap, null, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            pdf.finishPage(page); bitmap.recycle()
        }
        if (pageNo == 0) { pdf.close(); status.text = "تعذر قراءة الصور"; return }
        val ok = save("flipfile_${stamp()}.pdf", "application/pdf") { out -> pdf.writeTo(out) }
        pdf.close()
        status.text = if (ok) "تم إنشاء PDF من $pageNo صورة" else "فشل حفظ PDF"
    }

    private fun decode(uri: Uri): Bitmap? = try { contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } } catch (_: Exception) { null }
    private fun ensureSelection(): Boolean {
        if (chosen.isEmpty()) { status.text = "اختار صورة واحدة على الأقل أولاً"; return false }
        return true
    }
    private fun save(name: String, mime: String, writer: (OutputStream) -> Unit): Boolean = try {
        val values = android.content.ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name); put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/FlipFile")
        }
        val collection = if (mime == "application/pdf") MediaStore.Files.getContentUri("external") else MediaStore.Images.Media.getContentUri("external")
        val uri = contentResolver.insert(collection, values) ?: return false
        contentResolver.openOutputStream(uri)?.use(writer) ?: return false
        true
    } catch (_: Exception) { false }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    private fun section(root: LinearLayout, title: String) {
        val t = TextView(this).apply { text = title; textSize = 19f; setTextColor(navy); typeface = android.graphics.Typeface.DEFAULT_BOLD; setPadding(0, dp(22), 0, dp(8)) }
        root.addView(t, match())
    }
    private fun button(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 15f; setTextColor(if (color == orange) navy else -1); setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        setOnClickListener { action() }; isAllCaps = false
    }
    private fun space(h: Int) = android.view.View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
